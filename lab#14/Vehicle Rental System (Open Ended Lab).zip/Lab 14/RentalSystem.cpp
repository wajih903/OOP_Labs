#include "RentalSystem.h"
#include <iostream>
#include <iomanip>
#include <algorithm>

RentalSystem::RentalSystem()
    : nextVehicleId(1), nextCustomerId(1), nextRentalId(1) {}

Vehicle* RentalSystem::findVehicle(int vehicleId) {
    for (auto& v : fleet) {
        if (v->getId() == vehicleId) return v.get();
    }
    return nullptr;
}

Customer* RentalSystem::findCustomer(int customerId) {
    for (auto& c : customers) {
        if (c.getId() == customerId) return &c;
    }
    return nullptr;
}

Rental* RentalSystem::findActiveRentalForVehicle(int vehicleId) {
    for (auto& r : rentals) {
        if (r.getVehicleId() == vehicleId && r.isActive()) return &r;
    }
    return nullptr;
}

int RentalSystem::registerCustomer(const std::string& name) {
    int id = nextCustomerId++;
    customers.emplace_back(id, name);
    return id;
}

bool RentalSystem::processRental(int customerId, int vehicleId, int days) {
    if (days <= 0) {
        std::cout << "  [Rental rejected] Number of days must be positive.\n";
        return false;
    }

    Vehicle* vehicle = findVehicle(vehicleId);
    if (!vehicle) {
        std::cout << "  [Rental rejected] No vehicle with id " << vehicleId << ".\n";
        return false;
    }
    if (!vehicle->isAvailable()) {
        // R3: the system must prevent renting an already-rented vehicle.
        std::cout << "  [Rental rejected] Vehicle #" << vehicleId << " ("
                  << vehicle->getMakeModel() << ") is already rented.\n";
        return false;
    }

    Customer* customer = findCustomer(customerId);
    if (!customer) {
        std::cout << "  [Rental rejected] No customer with id " << customerId << ".\n";
        return false;
    }
    if (customer->hasActiveRental()) {
        // R2: a customer may hold at most one active rental at a time.
        std::cout << "  [Rental rejected] Customer #" << customerId << " ("
                  << customer->getName() << ") already has an active rental.\n";
        return false;
    }

    // ---- RUNTIME POLYMORPHISM HAPPENS HERE ----
    // `vehicle` is declared as Vehicle* (the base class), but it may
    // actually point to a Car, a Motorbike or a Truck. The call below is
    // resolved at RUNTIME via the vtable to whichever calculateCost()
    // override matches the object's real type. This is the single most
    // important line in the whole program: it is what lets RentalSystem
    // price ANY vehicle type it holds without an if/else chain checking
    // "is this a Truck? is this a Motorbike?" anywhere in this function.
    double cost = vehicle->calculateCost(days);

    int rentalId = nextRentalId++;
    rentals.emplace_back(rentalId, customerId, vehicleId, days, cost);

    vehicle->setAvailable(false);
    customer->setActiveRentalId(rentalId);

    std::cout << "  Rental #" << rentalId << " created: " << customer->getName()
              << " -> " << vehicle->getType() << " \"" << vehicle->getMakeModel()
              << "\" for " << days << " day(s), cost = Rs "
              << std::fixed << std::setprecision(2) << cost << "\n";
    return true;
}

bool RentalSystem::returnVehicle(int vehicleId) {
    Vehicle* vehicle = findVehicle(vehicleId);
    if (!vehicle) {
        std::cout << "  [Return rejected] No vehicle with id " << vehicleId << ".\n";
        return false;
    }

    Rental* rental = findActiveRentalForVehicle(vehicleId);
    if (!rental) {
        std::cout << "  [Return rejected] Vehicle #" << vehicleId << " has no active rental.\n";
        return false;
    }

    // R5: closing the record, not deleting it - history is preserved.
    rental->close();
    vehicle->setAvailable(true);

    Customer* customer = findCustomer(rental->getCustomerId());
    if (customer) {
        customer->setActiveRentalId(-1);
    }

    std::cout << "  Vehicle #" << vehicleId << " (" << vehicle->getMakeModel()
              << ") returned. Rental #" << rental->getId() << " closed.\n";
    return true;
}

void RentalSystem::printSummary() const {
    std::cout << "\n===================== RENTAL SUMMARY =====================\n";

    std::cout << "-- Active Rentals --\n";
    bool anyActive = false;
    for (const auto& r : rentals) {
        if (!r.isActive()) continue;
        anyActive = true;

        // Look up display names for the report. Using find-by-id keeps
        // Rental itself free of pointers into containers it doesn't own.
        std::string customerName = "Unknown";
        for (const auto& c : customers) {
            if (c.getId() == r.getCustomerId()) { customerName = c.getName(); break; }
        }
        std::string vehicleDesc = "Unknown";
        for (const auto& v : fleet) {
            if (v->getId() == r.getVehicleId()) {
                vehicleDesc = v->getType() + " \"" + v->getMakeModel() + "\"";
                break;
            }
        }

        std::cout << "  Rental #" << r.getId() << " | " << customerName
                  << " | " << vehicleDesc << " | " << r.getDays() << " day(s)"
                  << " | Rs " << std::fixed << std::setprecision(2) << r.getCost() << "\n";
    }
    if (!anyActive) {
        std::cout << "  (none)\n";
    }

    int availableCount = 0, rentedCount = 0;
    for (const auto& v : fleet) {
        v->isAvailable() ? ++availableCount : ++rentedCount;
    }

    std::cout << "\n-- Fleet Status --\n";
    std::cout << "  Available: " << availableCount << "  |  Rented: " << rentedCount
              << "  |  Total: " << fleet.size() << "\n";
    std::cout << "============================================================\n";
}

void RentalSystem::listVehicles() const {
    if (fleet.empty()) {
        std::cout << "  (no vehicles in the fleet yet)\n";
        return;
    }
    for (const auto& v : fleet) {
        v->displayInfo();
    }
}

void RentalSystem::listCustomers() const {
    if (customers.empty()) {
        std::cout << "  (no customers registered yet)\n";
        return;
    }
    for (const auto& c : customers) {
        std::cout << "  [#" << c.getId() << "] " << c.getName()
                  << (c.hasActiveRental()
                          ? " (active rental #" + std::to_string(c.getActiveRentalId()) + ")"
                          : " (no active rental)")
                  << "\n";
    }
}

bool RentalSystem::vehicleExists(int vehicleId) const {
    for (const auto& v : fleet) {
        if (v->getId() == vehicleId) return true;
    }
    return false;
}

bool RentalSystem::customerExists(int customerId) const {
    for (const auto& c : customers) {
        if (c.getId() == customerId) return true;
    }
    return false;
}
