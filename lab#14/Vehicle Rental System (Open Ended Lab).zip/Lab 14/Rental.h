#ifndef RENTAL_H
#define RENTAL_H

/*
 * Rental
 * ------
 * A closed record of "customer X rented vehicle Y for N days at cost C".
 *
 * DESIGN DECISION (see design_note.txt, Q3):
 *   RentalSystem is the single owner of all Rental records (a central
 *   ledger), not Customer and not Vehicle. Customer only remembers WHICH
 *   rental id is currently open against it; Vehicle only remembers whether
 *   IT is available. Neither class needs to know about the other directly,
 *   which keeps them small and focused (Single Responsibility).
 *
 * R5 requires that returning a vehicle does not delete the record but
 * marks it closed instead, so Rental stores an `active` flag rather than
 * being erased from RentalSystem's list.
 */
class Rental {
private:
    int id;
    int customerId;
    int vehicleId;
    int days;
    double cost;
    bool active;

public:
    Rental(int id, int customerId, int vehicleId, int days, double cost);

    int getId() const;
    int getCustomerId() const;
    int getVehicleId() const;
    int getDays() const;
    double getCost() const;
    bool isActive() const;

    void close(); // marks the rental as returned/closed, record is kept
};

#endif // RENTAL_H
