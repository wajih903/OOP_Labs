#include "Customer.h"

Customer::Customer(int id, const std::string& name)
    : id(id), name(name), activeRentalId(-1) {}

int Customer::getId() const {
    return id;
}

const std::string& Customer::getName() const {
    return name;
}

bool Customer::hasActiveRental() const {
    return activeRentalId != -1;
}

int Customer::getActiveRentalId() const {
    return activeRentalId;
}

void Customer::setActiveRentalId(int rentalId) {
    activeRentalId = rentalId;
}
