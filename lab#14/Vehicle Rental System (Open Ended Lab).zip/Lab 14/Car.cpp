#include "Car.h"
#include <iostream>

Car::Car(int id, const std::string& makeModel, double dailyRate, int seats)
    : Vehicle(id, makeModel, dailyRate), seats(seats) {}

double Car::calculateCost(int days) const {
    // Standard pricing rule for a Car: no surcharge, no discount.
    return dailyRate * days;
}

std::string Car::getType() const {
    return "Car";
}

void Car::displayInfo() const {
    Vehicle::displayInfo();
    std::cout << " | " << seats << " seats" << std::endl;
}

int Car::getSeats() const {
    return seats;
}
