#ifndef TRUCK_H
#define TRUCK_H

#include "Vehicle.h"

/*
 * Truck — always incurs a 20% surcharge on the base cost (overweight
 * handling fee), regardless of rental duration.
 * Type-specific attribute: payload capacity in tonnes.
 */
class Truck : public Vehicle {
private:
    double payloadTonnes;

public:
    Truck(int id, const std::string& makeModel, double dailyRate, double payloadTonnes);

    double calculateCost(int days) const override;
    std::string getType() const override;
    void displayInfo() const override;

    double getPayloadTonnes() const;
};

#endif // TRUCK_H
