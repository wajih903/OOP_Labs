#ifndef RENTALSYSTEM_H
#define RENTALSYSTEM_H

#include <vector>
#include <memory>
#include <string>
#include "Vehicle.h"
#include "Customer.h"
#include "Rental.h"

/*
 * RentalSystem
 * ------------
 * The single façade / composition root for the whole application (see
 * design_note.txt, Q3 and Q4). It owns the fleet, the customer list and
 * the full rental ledger, and it is the only class that is allowed to
 * mutate a Vehicle's availability or a Customer's active-rental state -
 * that keeps invariants like "a rented vehicle cannot be rented again" in
 * exactly one place instead of scattered across the codebase.
 *
 * Vehicles are stored as std::unique_ptr<Vehicle> - RentalSystem owns
 * them exclusively, they are cleaned up automatically (RAII, no memory
 * leaks, no manual delete), and the vector can safely hold a mix of Car,
 * Motorbike and Truck objects behind a single Vehicle* interface. This
 * heterogeneous collection accessed through a common base pointer is what
 * makes runtime polymorphism possible in processRental() below.
 */
class RentalSystem {
private:
    std::vector<std::unique_ptr<Vehicle>> fleet;
    std::vector<Customer> customers;
    std::vector<Rental> rentals;

    int nextVehicleId;
    int nextCustomerId;
    int nextRentalId;

    // Internal lookup helpers (non-owning raw pointers into containers
    // RentalSystem itself owns/manages - safe because unique_ptr in a
    // vector keeps a stable pointee address even if the vector reallocates).
    Vehicle* findVehicle(int vehicleId);
    Customer* findCustomer(int customerId);
    Rental* findActiveRentalForVehicle(int vehicleId);

public:
    RentalSystem();

    // R1: fleet management.
    // Templated factory: RentalSystem constructs the vehicle itself and
    // assigns its id internally, so the caller can never construct a
    // vehicle with an id that disagrees with the one RentalSystem uses to
    // track it (a mismatch that would be easy to introduce if the caller
    // had to supply a pre-built unique_ptr with its own id baked in).
    // Usage: system.addVehicle<Car>("Honda Civic", 2500.0, 5);
    template <typename VehicleType, typename... Args>
    int addVehicle(Args&&... args) {
        int id = nextVehicleId++;
        fleet.push_back(std::make_unique<VehicleType>(id, std::forward<Args>(args)...));
        return id;
    }

    // R2: customer registration. Returns the auto-assigned unique id.
    int registerCustomer(const std::string& name);

    // R3 + R4: process a rental. Returns true on success; on failure it
    // prints the reason and leaves all state unchanged.
    bool processRental(int customerId, int vehicleId, int days);

    // R5: return a vehicle. Returns true on success.
    bool returnVehicle(int vehicleId);

    // R6: reporting.
    void printSummary() const;

    // Helpers for the interactive menu (main.cpp) so the user can see
    // valid ids before being asked to type one in.
    void listVehicles() const;
    void listCustomers() const;
    bool vehicleExists(int vehicleId) const;
    bool customerExists(int customerId) const;
};

#endif // RENTALSYSTEM_H
