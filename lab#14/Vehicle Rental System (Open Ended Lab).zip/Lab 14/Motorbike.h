#ifndef MOTORBIKE_H
#define MOTORBIKE_H

#include "Vehicle.h"

/*
 * Motorbike — 10% discount is applied when a rental lasts longer than 7 days.
 * Type-specific attribute: engine displacement in cc.
 */
class Motorbike : public Vehicle {
private:
    int engineCC;

public:
    Motorbike(int id, const std::string& makeModel, double dailyRate, int engineCC);

    double calculateCost(int days) const override;
    std::string getType() const override;
    void displayInfo() const override;

    int getEngineCC() const;
};

#endif // MOTORBIKE_H
