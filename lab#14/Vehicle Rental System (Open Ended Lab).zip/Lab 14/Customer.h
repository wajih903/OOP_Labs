#ifndef CUSTOMER_H
#define CUSTOMER_H

#include <string>

/*
 * Customer
 * --------
 * Holds identity data plus a single piece of state: the id of the rental
 * currently open against this customer (-1 if none). R2 requires that a
 * customer may hold at most one active rental at a time; storing just the
 * id (rather than a pointer/reference into RentalSystem's rental list)
 * keeps Customer decoupled from how RentalSystem stores rentals, and
 * avoids dangling references if the rental list is ever reallocated.
 */
class Customer {
private:
    int id;
    std::string name;
    int activeRentalId; // -1 means "no active rental"

public:
    Customer(int id, const std::string& name);

    int getId() const;
    const std::string& getName() const;

    bool hasActiveRental() const;
    int getActiveRentalId() const;
    void setActiveRentalId(int rentalId); // pass -1 to clear
};

#endif // CUSTOMER_H
