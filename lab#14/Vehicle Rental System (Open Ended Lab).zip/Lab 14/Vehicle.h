#ifndef VEHICLE_H
#define VEHICLE_H

#include <string>

/*
 * Vehicle
 * -------
 * Abstract base class representing the common interface shared by every
 * vehicle in the fleet (Car, Motorbike, Truck, ...).
 *
 * DESIGN DECISION (see design_note.txt, Q1 and Q2):
 *   - Car / Motorbike / Truck are modelled as subclasses of Vehicle
 *     because an "is-a" relationship genuinely holds: every concrete
 *     vehicle IS a Vehicle that can be rented, returned and priced, but
 *     each one prices itself differently. That behavioural difference is
 *     exactly what virtual dispatch is for.
 *   - calculateCost() is declared as a pure virtual method on Vehicle
 *     (not a free function, not a method on Rental) because the pricing
 *     RULE is an intrinsic property of the vehicle TYPE (a Truck is always
 *     20% more expensive per day, a Motorbike is cheaper past 7 days).
 *     Keeping the rule next to the data it depends on avoids a giant
 *     switch/if-chain elsewhere in the code and lets new vehicle types be
 *     added without touching any existing class.
 *
 * All data members are private/protected; access is only through the
 * public interface below (encapsulation).
 */
class Vehicle {
protected:
    int id;                 // unique fleet id, assigned by RentalSystem
    std::string makeModel;  // e.g. "Toyota Corolla"
    double dailyRate;       // base cost per day, before type-specific rules
    bool available;         // true = can be rented, false = currently rented

public:
    Vehicle(int id, const std::string& makeModel, double dailyRate);

    // A base class used polymorphically through pointers/references must
    // have a virtual destructor, otherwise deleting a derived object
    // through a Vehicle* would be undefined behaviour.
    virtual ~Vehicle() = default;

    // ---- Pure virtual interface (abstraction) ----
    // Every concrete vehicle type MUST provide its own pricing rule.
    virtual double calculateCost(int days) const = 0;

    // Every concrete vehicle type MUST identify itself.
    virtual std::string getType() const = 0;

    // Default textual summary; derived classes extend it to mention
    // their own type-specific attribute (seats, payload, etc).
    virtual void displayInfo() const;

    // ---- Accessors (encapsulation: no public data members) ----
    int getId() const;
    const std::string& getMakeModel() const;
    double getDailyRate() const;
    bool isAvailable() const;
    void setAvailable(bool status);
};

#endif // VEHICLE_H
