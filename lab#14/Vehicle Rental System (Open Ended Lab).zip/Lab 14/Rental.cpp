#include "Rental.h"

Rental::Rental(int id, int customerId, int vehicleId, int days, double cost)
    : id(id), customerId(customerId), vehicleId(vehicleId),
      days(days), cost(cost), active(true) {}

int Rental::getId() const {
    return id;
}

int Rental::getCustomerId() const {
    return customerId;
}

int Rental::getVehicleId() const {
    return vehicleId;
}

int Rental::getDays() const {
    return days;
}

double Rental::getCost() const {
    return cost;
}

bool Rental::isActive() const {
    return active;
}

void Rental::close() {
    active = false;
}
