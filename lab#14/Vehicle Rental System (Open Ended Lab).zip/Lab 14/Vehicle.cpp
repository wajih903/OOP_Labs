#include "Vehicle.h"
#include <iostream>
#include <iomanip>

Vehicle::Vehicle(int id, const std::string& makeModel, double dailyRate)
    : id(id), makeModel(makeModel), dailyRate(dailyRate), available(true) {}

void Vehicle::displayInfo() const {
    std::cout << "[#" << id << "] " << std::left << std::setw(9) << getType()
              << " | " << std::left << std::setw(18) << makeModel
              << " | Rs " << std::fixed << std::setprecision(2) << std::setw(8) << dailyRate << "/day"
              << " | " << (available ? "AVAILABLE" : "RENTED");
}

int Vehicle::getId() const {
    return id;
}

const std::string& Vehicle::getMakeModel() const {
    return makeModel;
}

double Vehicle::getDailyRate() const {
    return dailyRate;
}

bool Vehicle::isAvailable() const {
    return available;
}

void Vehicle::setAvailable(bool status) {
    available = status;
}
