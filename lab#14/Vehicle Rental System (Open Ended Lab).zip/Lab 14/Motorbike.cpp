#include "Motorbike.h"
#include <iostream>

Motorbike::Motorbike(int id, const std::string& makeModel, double dailyRate, int engineCC)
    : Vehicle(id, makeModel, dailyRate), engineCC(engineCC) {}

double Motorbike::calculateCost(int days) const {
    double cost = dailyRate * days;
    // R4: rentals longer than 7 days receive a 10% discount.
    if (days > 7) {
        cost *= 0.90;
    }
    return cost;
}

std::string Motorbike::getType() const {
    return "Motorbike";
}

void Motorbike::displayInfo() const {
    Vehicle::displayInfo();
    std::cout << " | " << engineCC << "cc" << std::endl;
}

int Motorbike::getEngineCC() const {
    return engineCC;
}
