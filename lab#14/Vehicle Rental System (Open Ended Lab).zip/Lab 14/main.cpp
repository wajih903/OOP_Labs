/*
 * Vehicle Rental System — OOP with C++ (In-Class Lab)
 * ----------------------------------------------------
 * main() is a text menu that lets the USER drive the system
 * interactively: add vehicles, register customers, process rentals,
 * return vehicles, and print the summary, all through typed input.
 *
 * See RentalSystem::processRental() in RentalSystem.cpp for the exact
 * line where runtime polymorphism occurs (a Vehicle* base pointer calling
 * the virtual calculateCost()).
 */

#include <iostream>
#include <limits>
#include <string>
#include "RentalSystem.h"
#include "Car.h"
#include "Motorbike.h"
#include "Truck.h"

// ---------------------------------------------------------------------
// Small input helpers. Console menus live and die by how well they
// survive bad input (letters typed where a number is expected, empty
// lines, etc.) so these are centralised here instead of repeated inline.
// ---------------------------------------------------------------------

int readInt(const std::string& prompt) {
    int value;
    while (true) {
        std::cout << prompt;
        if (std::cin >> value) {
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            return value;
        }
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "  Please enter a whole number.\n";
    }
}

double readDouble(const std::string& prompt) {
    double value;
    while (true) {
        std::cout << prompt;
        if (std::cin >> value) {
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            return value;
        }
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "  Please enter a number.\n";
    }
}

std::string readLine(const std::string& prompt) {
    std::string value;
    while (true) {
        std::cout << prompt;
        std::getline(std::cin, value);
        if (!value.empty()) return value;
        std::cout << "  This field cannot be empty.\n";
    }
}

// ---------------------------------------------------------------------
// Menu actions. Each one is a thin wrapper that gathers input from the
// user and hands it to RentalSystem's public interface - all business
// rules (availability checks, one-rental-per-customer, pricing, etc.)
// stay inside RentalSystem, not here.
// ---------------------------------------------------------------------

void menuAddVehicle(RentalSystem& system) {
    std::cout << "\n-- Add Vehicle --\n";
    std::cout << "  1. Car\n  2. Motorbike\n  3. Truck\n";
    int choice = readInt("  Choose vehicle type: ");

    std::string makeModel = readLine("  Make/Model (e.g. Toyota Corolla): ");
    double dailyRate = readDouble("  Daily rate: ");

    int newId = -1;
    switch (choice) {
        case 1: {
            int seats = readInt("  Number of seats: ");
            newId = system.addVehicle<Car>(makeModel, dailyRate, seats);
            break;
        }
        case 2: {
            int cc = readInt("  Engine size (cc): ");
            newId = system.addVehicle<Motorbike>(makeModel, dailyRate, cc);
            break;
        }
        case 3: {
            double payload = readDouble("  Payload capacity (tonnes): ");
            newId = system.addVehicle<Truck>(makeModel, dailyRate, payload);
            break;
        }
        default:
            std::cout << "  Invalid vehicle type, nothing added.\n";
            return;
    }
    std::cout << "  Added. Assigned vehicle id: #" << newId << "\n";
}

void menuRegisterCustomer(RentalSystem& system) {
    std::cout << "\n-- Register Customer --\n";
    std::string name = readLine("  Customer name: ");
    int id = system.registerCustomer(name);
    std::cout << "  Registered. Assigned customer id: #" << id << "\n";
}

void menuProcessRental(RentalSystem& system) {
    std::cout << "\n-- Process Rental --\n";
    std::cout << "Current customers:\n";
    system.listCustomers();
    std::cout << "Current vehicles:\n";
    system.listVehicles();

    int customerId = readInt("\n  Customer id: ");
    if (!system.customerExists(customerId)) {
        std::cout << "  No customer with that id.\n";
        return;
    }
    int vehicleId = readInt("  Vehicle id: ");
    if (!system.vehicleExists(vehicleId)) {
        std::cout << "  No vehicle with that id.\n";
        return;
    }
    int days = readInt("  Number of days: ");

    system.processRental(customerId, vehicleId, days);
}

void menuReturnVehicle(RentalSystem& system) {
    std::cout << "\n-- Return Vehicle --\n";
    system.listVehicles();
    int vehicleId = readInt("\n  Vehicle id to return: ");
    system.returnVehicle(vehicleId);
}

void printMenu() {
    std::cout << "\n================ VEHICLE RENTAL SYSTEM ================\n";
    std::cout << "  1. Add a vehicle to the fleet\n";
    std::cout << "  2. Register a customer\n";
    std::cout << "  3. Process a rental\n";
    std::cout << "  4. Return a vehicle\n";
    std::cout << "  5. List all vehicles\n";
    std::cout << "  6. List all customers\n";
    std::cout << "  7. Print summary report\n";
    std::cout << "  0. Exit\n";
    std::cout << "========================================================\n";
}

int main() {
    RentalSystem system;
    bool running = true;

    std::cout << "Welcome to the Vehicle Rental System.\n";

    while (running) {
        printMenu();
        int choice = readInt("Enter your choice: ");

        switch (choice) {
            case 1: menuAddVehicle(system);       break;
            case 2: menuRegisterCustomer(system); break;
            case 3: menuProcessRental(system);    break;
            case 4: menuReturnVehicle(system);    break;
            case 5: std::cout << "\n-- Fleet --\n"; system.listVehicles();   break;
            case 6: std::cout << "\n-- Customers --\n"; system.listCustomers(); break;
            case 7: system.printSummary();        break;
            case 0:
                std::cout << "Goodbye.\n";
                running = false;
                break;
            default:
                std::cout << "  Invalid choice, please pick an option from the menu.\n";
        }
    }

    return 0;
}
