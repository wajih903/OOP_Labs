#include "Truck.h"
#include <iostream>

Truck::Truck(int id, const std::string& makeModel, double dailyRate, double payloadTonnes)
    : Vehicle(id, makeModel, dailyRate), payloadTonnes(payloadTonnes) {}

double Truck::calculateCost(int days) const {
    double cost = dailyRate * days;
    // R4: Trucks always incur a 20% overweight handling surcharge.
    cost *= 1.20;
    return cost;
}

std::string Truck::getType() const {
    return "Truck";
}

void Truck::displayInfo() const {
    Vehicle::displayInfo();
    std::cout << " | " << payloadTonnes << "t payload" << std::endl;
}

double Truck::getPayloadTonnes() const {
    return payloadTonnes;
}
