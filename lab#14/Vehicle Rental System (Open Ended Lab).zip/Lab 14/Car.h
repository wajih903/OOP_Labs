#ifndef CAR_H
#define CAR_H

#include "Vehicle.h"

/*
 * Car — standard pricing (dailyRate * days), no surcharge or discount.
 * Type-specific attribute: number of seats.
 */
class Car : public Vehicle {
private:
    int seats;

public:
    Car(int id, const std::string& makeModel, double dailyRate, int seats);

    double calculateCost(int days) const override;
    std::string getType() const override;
    void displayInfo() const override;

    int getSeats() const;
};

#endif // CAR_H
